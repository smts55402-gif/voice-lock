package com.zax.voicelock

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        admin = ComponentName(this, MyDeviceAdminReceiver::class.java)

        val prefs = getSharedPreferences("voice_lock", Context.MODE_PRIVATE)
        val editWord = findViewById<EditText>(R.id.editLockWord)
        val textStatus = findViewById<TextView>(R.id.textStatus)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnAdmin = findViewById<Button>(R.id.btnAdmin)
        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)

        editWord.setText(prefs.getString("lock_word", "lock karo"))

        askPermissions()

        btnSave.setOnClickListener {
            val word = editWord.text.toString().trim()
            if (word.isEmpty()) {
                Toast.makeText(this, "Pehle lock word likho, jaise tumhara naam", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.edit().putString("lock_word", word).apply()
            textStatus.text = "Lock word save ho gaya: $word"
            Toast.makeText(this, "Save ho gaya: $word", Toast.LENGTH_SHORT).show()
        }

        btnAdmin.setOnClickListener {
            if (dpm.isAdminActive(admin)) {
                textStatus.text = "Device Admin pehle se ON hai"
            } else {
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Voice se phone lock karne ke liye Device Admin chahiye."
                    )
                }
                startActivity(intent)
            }
        }

        btnStart.setOnClickListener {
            if (!dpm.isAdminActive(admin)) {
                Toast.makeText(this, "Pehle Device Admin ON karo", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                Toast.makeText(this, "Pehle Microphone permission do", Toast.LENGTH_LONG).show()
                askPermissions()
                return@setOnClickListener
            }
            val intent = Intent(this, ListeningService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            textStatus.text = "Sunna shuru ho gaya. Lock word bolo to phone lock hoga."
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, ListeningService::class.java))
            textStatus.text = "Sunna band ho gaya."
        }
    }

    private fun askPermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 100)
    }
}
