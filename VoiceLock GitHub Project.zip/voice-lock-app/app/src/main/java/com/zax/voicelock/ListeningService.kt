package com.zax.voicelock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * Voice Lock service - Zax ke liye
 * Kaam: background me sunta rahega, lock word sunte hi phone lock kar dega.
 * Lock word SharedPreferences me "lock_word" key se aata hai.
 * Default: "lock karo"
 *
 * Note: SpeechRecognizer ko internet chahiye hota hai (Google recognition).
 * Vivo OriginOS me is service ko kill na kare, isliye:
 * Settings > Apps > Voice Lock > Battery > Unrestricted + Autostart ON karna.
 */
class ListeningService : Service() {

    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isListening = false

    private fun getLockWord(): String {
        val prefs = getSharedPreferences("voice_lock", Context.MODE_PRIVATE)
        return prefs.getString("lock_word", "lock karo") ?: "lock karo"
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startListeningLoop()
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "voice_lock_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Voice Lock Listening",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Voice Lock sun raha hai")
            .setContentText("Lock word bolte hi phone lock ho jayega")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    private fun startListeningLoop() {
        if (isListening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e("VoiceLock", "Speech recognition available nahi hai is phone me")
            stopSelf()
            return
        }
        isListening = true
        startOneListen()
    }

    private fun startOneListen() {
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    // Error aaye to 1 sec baad dobara sunna shuru karo
                    handler.postDelayed({ startOneListen() }, 1000)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val heard = matches?.firstOrNull() ?: ""
                    Log.d("VoiceLock", "Suna: $heard")
                    val lockWord = getLockWord().trim().lowercase()
                    if (heard.lowercase().contains(lockWord) && lockWord.isNotEmpty()) {
                        lockPhoneNow()
                    }
                    handler.postDelayed({ startOneListen() }, 500)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val heard = matches?.firstOrNull() ?: ""
                    val lockWord = getLockWord().trim().lowercase()
                    if (heard.lowercase().contains(lockWord) && lockWord.isNotEmpty()) {
                        lockPhoneNow()
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e("VoiceLock", "Listen error: ${e.message}")
            handler.postDelayed({ startOneListen() }, 1000)
        }
    }

    private fun lockPhoneNow() {
        try {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(this, MyDeviceAdminReceiver::class.java)
            if (dpm.isAdminActive(admin)) {
                dpm.lockNow()
            } else {
                Log.e("VoiceLock", "Device Admin active nahi hai - pehle MainActivity se ON karo")
            }
        } catch (e: Exception) {
            Log.e("VoiceLock", "Lock failed: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isListening = false
        recognizer?.destroy()
        handler.removeCallbacksAndMessages(null)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
