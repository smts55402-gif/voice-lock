# Voice Lock - Zax ke liye

Bolte hi phone lock karne wala app. Free, koi subscription nahi.

## Ye app kya karta hai
- Tum ek lock word set karte ho, jaise tumhara naam ya "lock karo"
- App background me sunta rehta hai
- Wahi word sunte hi phone lock ho jata hai (Device Admin se)
- Koi bhi naam nahi, sirf wahi word jo tumne save kiya hai

## GitHub se APK kaise banaye - PC nahi chahiye, free hai

1. GitHub par naya repo banao, naam: `voice-lock`
2. Is folder ki saari files us repo me upload kar do
3. GitHub par repo kholo > **Actions** tab > **Build APK** > **Run workflow** dabao
   - Ya files push karte hi apne aap build shuru ho jayega
4. Build khatam hone par **Artifacts** me `VoiceLock-debug-apk` milega, usko download karo
5. Phone me APK install karo. Unknown apps install ki permission maangega to Allow karna.

## Phone me setup - install ke baad
1. App kholo, lock word likho, **Lock Word Save Karo** dabao
2. **1. Device Admin ON Karo** dabao, Activate karo
3. Microphone permission Allow karo
4. **2. Sunna Shuru Karo** dabao
5. Vivo me zaroori: Settings > Apps > Voice Lock > Battery > Unrestricted + Autostart ON
   - Nahi to Vivo background me sunna band kar dega

## Test
Phone unlock rakhkar lock word bolo. Phone lock hona chahiye.
Fingerprint / PIN se wapas unlock karo - voice unlock nahi hai, sirf voice lock hai.

## Limitations - sach baat
- Speech recognition ko internet chahiye hota hai
- Mic hamesha ON rahega, battery thodi zyada kharch hogi
- Jo bhi tumhara lock word bolega, phone lock ho jayega - ye security nahi, सुविधा hai
- Apna PIN / fingerprint lock ON hi rakhna
- Ye app Play Store wale Vokey jaisa premium trap nahi hai - isme koi payment nahi hai

## Files
- `app/src/main/java/com/zax/voicelock/MainActivity.kt` - lock word save + start/stop
- `app/src/main/java/com/zax/voicelock/ListeningService.kt` - background me sunna + lock karna
- `app/src/main/java/com/zax/voicelock/MyDeviceAdminReceiver.kt` - Device Admin
- `.github/workflows/build-apk.yml` - GitHub Actions se free APK build
